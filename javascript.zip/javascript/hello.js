        document.writeln("hello world from javascript");
        document.writeln("<h1>hello world from javascript");

        var a,b, sum;
       var name=prompt("Enter your name");
        a=parseInt(prompt("Enter your first num:","Enter a number"));
        b=parseInt(prompt("Enter your second num:","Enter a number"));
        sum=a+b;
        
        document.write("<br>"+"Hello "+name+"<br>");
        document.write("Addition of 2 nums is: "+sum);
        alert("Thankyou");
       